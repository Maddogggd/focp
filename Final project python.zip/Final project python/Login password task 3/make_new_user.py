# make_new_user.py
from pass_word import read_passwords, write_passwords, encrypt_password

def make_new_user():
    usernames = [user[0] for user in read_passwords()]
    
    new_username = input("Make new username: ").lower()
    
    if new_username in usernames:
        print("Error! Cannot add. Username already exists.")
        return

    full_name = input("Enter your full name: ")
    password = input("Create a  password: ")

    secret_key = encrypt_password(password)
    
    passwords = read_passwords()
    passwords.append((new_username, full_name, secret_key))
    
    write_passwords(passwords)
    print("Successful! User Created.")

if __name__ == "__main__": 
    make_new_user()