# find_user.py
from pass_word import read_passwords, write_passwords

def find_user():
    usernames = [user[0] for user in read_passwords()]
    
    username_to_delete = input("Enter your username: ").lower()
    
    passwords = read_passwords()
    updated_passwords = [user for user in passwords if user[0] != username_to_delete]

    if len(passwords) == len(updated_passwords):
        print("Error! Username does not exist.")
        return

    write_passwords(updated_passwords)
    print("Succesful! User Deleted.")

if __name__ == "__main__": 
    find_user()
