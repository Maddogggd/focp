def get_positive_integer_input(prompt):
    while True:
        user_input = input(prompt)
        if user_input.isdigit():
            return int(user_input)
        print("Please enter a valid positive integer!")

def get_yes_no_input(prompt):
    while True:
        user_input = input(prompt).strip().capitalize()
        if user_input in ('Yes', 'No'):
            return user_input == 'Yes'
        print('Please answer "Yes" or "No".')

# Main loop for user input
num_of_pizzas = get_positive_integer_input("Can you tell me how many pizzas were ordered? ")
delivery_is_needed = get_yes_no_input("Does delivery have to be done? (Yes/No) ")
tuesday = get_yes_no_input("Does it fall on a Tuesday? (Yes/No) ")
app = get_yes_no_input("Was the app used by the customer? (Yes/No) ")

# Constants
PIZZA_PRICE = 12.00
DISCOUNT_TUESDAY = 0.5
DISCOUNT_APP = 0.25
DELIVERY_FEE = 2.50
MIN_DELIVERY_ORDER = 5

# Calculations
total_price = num_of_pizzas * PIZZA_PRICE

if delivery_is_needed and num_of_pizzas < MIN_DELIVERY_ORDER:
    total_price += DELIVERY_FEE

if tuesday:
    total_price *= (1 - DISCOUNT_TUESDAY)

if app:
    total_price *= (1 - DISCOUNT_APP)

# Formatted Output
print("\nBPP Pizza Price Calculator")
print("==========================\n")
print(f"Can you tell me how many pizzas were ordered? {num_of_pizzas}")
print(f"Does delivery have to be done? {'Yes' if delivery_is_needed else 'No'}")
print(f"Does it fall on a Tuesday? {'Yes' if tuesday else 'No'}")
print(f"Was the app used by the customer? {'Yes' if app else 'No'}\n")
print(f"Total Price: £{total_price:.2f}")
